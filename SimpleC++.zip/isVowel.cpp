#include <iostream>

using namespace std;

bool isVowel(char x);
char getvowel();

int main() 
{
 char vowel;

 bool lavowel; 
 
 vowel=getvowel();
 
 lavowel=isVowel(vowel);
 
 if (lavowel==true)
 {
 cout<<vowel<<" is a vowel: "<<endl;
}
 else
 {
 
 cout<<vowel<<" is not a vowel: "<<endl;
}
  
}

char getvowel()
{
char x;
cout<<"Enter a vowel"	<<endl;
cin>>x;
return x;
}
 
 
 bool isVowel(char x)
{

if (x=='a'||x=='e'||x=='i'||x=='o'||x=='u'||x=='A'||x=='E'||x=='I'||x=='O'||x=='U')
 {

return true;
 }
 
 else
 {
 return false;

 }
}