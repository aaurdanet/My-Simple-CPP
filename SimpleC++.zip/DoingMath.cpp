#include<iostream>
using namespace std;

int getNum();
int calSum(int,int);
int calDiff(int,int);
int calProd(int,int);
int calQuot(int,int);
void outSum(int);
void outDiff(int);
void outProd(int);
void outQuot(int);

int main()
{
	int num1,num2,sum,diff,prod,quot;
	
	num1=getNum();
	num2=getNum();
	
	sum=calSum(num1,num2);
outSum(sum);
	
	diff=calDiff(num1,num2);
outDiff(diff);
	
	prod=calProd(num1,num2);
outProd(prod);

	quot=calQuot(num1,num2);
outQuot(quot);

}
	int getNum()
{
	int H;
	cout<<"Enter a number"<<endl;
	cin>>H;
return H;

}


void outSum(int x)
{
	cout<<"The sum is "<<x<<endl;
}
void outDiff(int x)
{
	cout<<"The difference is"<<x<<endl;
}
void outProd(int x)
{
		cout<<"The product is"<<x<<endl;
}
void outQuot(int x)
{
	
cout<<"The quotient is"<<x<<endl;	
}


	int calSum(int x, int y)
	{
	return x+y;	
	}
	
	int calDiff(int x, int y)
	{
	return x-y;	
	}

	int calProd(int x, int y)
	{
	return x*y;	
	}
	
	int calQuot(int x, int y)
	{
	return x/y;	
	}
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	

