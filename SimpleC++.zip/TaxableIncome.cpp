#include <iostream>
#include  <iomanip>
using namespace std;                                   
 
int main()
{
	double income, taxrate, taxdue, finalincome;
	
cout<<"Insert your income "<<endl;
cin>> income;
 
 if (income>=0 && income<=50000)
taxrate=0+0.05*income;
else if(income>50000)
taxrate=2500+0.07*income;
else if(income>=100000)
taxrate=6000+0.09*income;

taxdue=taxrate;
finalincome=income-taxrate;

cout<<"Your tax due is "<<taxdue<<endl;
cout<<"Your final income is "<<finalincome<<endl;
}
