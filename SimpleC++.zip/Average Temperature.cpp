#include <iostream>
#include  <iomanip>
using namespace std;                                   
 
int main()
{
	double maxTemp, minTemp,average;
	
	cout<<"Insert max temperature in Fahrenheit or Celsius: "<<endl;
	cin>>maxTemp;
	cout<<"Insert min temperature Fahrenheit or Celsius: "<<endl;
	cin>>minTemp;
	
	average=(maxTemp+minTemp)/2;
	
	
	cout<<"The average temperature is "<<average<<endl;
}
