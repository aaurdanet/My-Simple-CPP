#include <iostream>
using namespace std;
 

int findNum(int, int[]);

int main()
{
int saleNum;
int numArray[12]={1,3,5,4,7,2,99,16,45,67,89,45}; 
int flag;

cout<<"Enter Item Number:"<<endl;
cin>>saleNum;

flag=findNum(saleNum, numArray);
if (flag== -1)
cout<<"NOT FOUND"<<endl;
else
cout<<"Item found, it is in index"<<flag<<endl;

}
int findNum(int x, int y[12])
{
	int i;
	for(i=0;i<12;i++)
	{if (x==y[i])
	return i;
	}
	return -1;
}
