#include <iostream>
using namespace std;

int getNum();
int squareNum(int);
void outNum(int);

int main()
{
int num1,square;

num1=getNum();
square=squareNum(num1);
outNum(square);
}

int getNum()
{
int H;
cout<<"Enter number to square"<<endl;
cin>>H;
return H;		
}

void outNum(int x)
{
cout<<"The square of the number is "<<x<<endl;
}

int squareNum(int x)
{
		return x*x;	
	}


