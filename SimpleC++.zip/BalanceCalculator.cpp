#include <iostream>
#include  <iomanip>
using namespace std;                                   
 
int main()
{
	double currentBankbalance, oldBalance, deposit, withdraw;
	
	cout<<"Enter current old balance"<<endl;
	cin>>oldBalance;
	
	cout<<"How much do you want to deposit?"<<endl;
	cin>>deposit;
	
	cout<<"How much do you want to withdraw?"<<endl;
	cin>>withdraw;
	
	currentBankbalance=oldBalance+deposit-withdraw;
	
	
	cout<<"Your new balance is "<<currentBankbalance<<endl;
	return 0;
	
}

	
