#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    int years; 
    double bonus, totalsales, comision, basesalary, additionalbonus, monthlypaycheck;
	cout << fixed << showpoint << setprecision(2);;

	cout<<"Enter your base salary: "<<endl;
	cin>>basesalary;
	
	cout<<"Enter number of years working: "<<endl;
	cin>>years;
	
	cout<<"Enter total sales in the last month: "<<endl;
	cin>>totalsales;
	cout<<endl;
	
	if(years>5)
	bonus=basesalary+(20*years);
	else if (years<=5)
	bonus=basesalary+(10*years);
	cout<<endl;
	
	
	if (totalsales<=10000 && totalsales>=5000)
	additionalbonus=totalsales*0.03;
	else if (totalsales>10000)
	additionalbonus=totalsales*0.06;
	cout<<endl;
  	monthlypaycheck=bonus+additionalbonus;
	
	
	cout<<"Your monthly paycheck is: "<<monthlypaycheck<<endl;
}