#include <iostream>
#include  <iomanip>
using namespace std;                                   
 
int main()
{
	int grade;
	char letter;
	
	cout<<"Insert your grade "<<endl;
	cin>>grade;

if(grade>100||grade<0)
cout<<"Input error";

switch(grade/10)
{
	case 10: 
	case 9: letter='A';break;
	case 8: letter='B';break;
	case 7: letter='C';break;
	case 6: letter='D';break;
	default :letter='F';break;
	}	
cout<<"Your letter grade is "<<letter<<endl;
}

