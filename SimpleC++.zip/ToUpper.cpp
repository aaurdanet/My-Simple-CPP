#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

int main() {
	char a[50];

	
	
	cout<<"ENTER A STRING"<<endl;
	cin>>a;
	
	int length = strlen(a);
	
	for(int i = 0; i < length; i++)
	{
		cout << static_cast<char>(toupper(a[i]));
	}



return 0;
}
