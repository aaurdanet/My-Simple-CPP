#include <iostream>
using namespace std;
 int main()
{
 int integer, count;		
int sum=0;
double avg;


 while (count<100)
 {
 	cout<<"Enter new integer"<<endl;
	 cin>>
	 integer;
	 count++;
 	sum=integer+sum;
 	
 }
avg=sum/count;



cout<<"The average of the sum is "<<avg<<endl;

 cout<<"Your sum is "<<sum<<endl;



}
