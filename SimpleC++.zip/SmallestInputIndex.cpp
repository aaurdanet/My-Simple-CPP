#include <iostream>
using namespace std;

int smallestIndex(int arr[],int size)

{
int smallest=arr[0];
int i=0;
for(i=0;i<size;i++)
{
if(arr[i]<smallest)
smallest=arr[i];
}

for( i=0;i<size;i++)
{
if(arr[i]==smallest)
return i;
}
}

int main()
{
int arr[15];
cout<<"Input 15 integers:"<<endl;
for(int i=0;i<15;i++)
{
cin>>arr[i];

}
cout<<"Smallest Index is: "<<smallestIndex(arr,15);
}

  



