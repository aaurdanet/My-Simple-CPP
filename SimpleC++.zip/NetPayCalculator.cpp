#include <iostream>
#include  <iomanip>
using namespace std;                                   
 
int main()
{
	double hours, payPerhour, gross, tax, Netpay;
	cout<<fixed<<showpoint<<setprecision(2);
	
	cout<<"How many hours do you work?"<<endl;
	cin>>hours;
	
	cout<<"How much do you make hourly?"<<endl;
	cin>>payPerhour;
	
	gross=hours* payPerhour;
	tax=0.0765*payPerhour;
	Netpay=gross-tax;
	
	cout<<"Your net pay will be:"<<endl;
	cout<<Netpay;
	
}