#include <iostream>

using namespace std;
float getNum()
{
float num;
cout<<"Enter number : ";
cin>>num;
return num;
}
float add(float num1,float num2)
{
float sum=num1+num2;
return sum;
}
void outSum(float sum)
{
cout<<"sum is "<<sum<<endl;
}
int main() {
float num1,num2,sum;
num1=getNum();
num2=getNum();
while(num1!=0 || num2!=0)
{
sum=add(num1,num2);
outSum(sum);
num1=getNum();
if(num1==0)
break;
num2=getNum();
}

}
