#include <iostream>
using namespace std;
 int main()
{
	int test1;
	int test2;
	int test3; 
	int totalclass;
	int count;
	int i;
	double avg;
	double Classavg, sum;
	for (i=0;i<10;i++)
	{
		cout<<"Enter your Grade for exam 1"<<endl;
		cin>>test1;
cout<<"Enter your Grade for exam 2"<<endl;
		cin>>test2;
			cout<<"Enter your Grade for exam 3"<<endl;
		cin>>test3;
	avg=(test1+test2+test3)/3;
		
cout<<"Your average is "<<avg<<endl;
sum=test1+test2+test3;

totalclass=totalclass+avg;


}
Classavg=totalclass/10;
cout<<" The class room average is "<<Classavg<<endl;
}

